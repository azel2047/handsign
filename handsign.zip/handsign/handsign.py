import cv2
import mediapipe as mp
import time
import threading
import os
from gtts import gTTS
import playsound


mp_drawing = mp.solutions.drawing_utils
mp_hands = mp.solutions.hands
mp_face_detection = mp.solutions.face_detection



gesture_dict = {
    0: "Halo semuanya",
    1: "Nama saya",
    2: "Seno",
    3: "Saya kuliah di",
    4: "STT Nurul Fikri",
    5: "Salam kenal ya guys"
}


def count_fingers(hand_landmarks, hand_label):
    tips_ids = [4, 8, 12, 16, 20]
    fingers = []

    # cek jempol
    if hand_label == "Right":
        fingers.append(1 if hand_landmarks.landmark[tips_ids[0]].x <
                           hand_landmarks.landmark[tips_ids[0] - 1].x else 0)
    else:  # Left
        fingers.append(1 if hand_landmarks.landmark[tips_ids[0]].x >
                           hand_landmarks.landmark[tips_ids[0] - 1].x else 0)

    # cek 4 jari lain
    for id in range(1, 5):
        fingers.append(1 if hand_landmarks.landmark[tips_ids[id]].y <
                           hand_landmarks.landmark[tips_ids[id] - 2].y else 0)

    return fingers.count(1)

# ==============================
# Fungsi TTS (pakai gTTS)
# ==============================
def speak(text):
    def _run():
        try:
            # buat file audio dari Google TTS
            tts = gTTS(text=text, lang="id")
            filename = "temp_audio.mp3"
            tts.save(filename)

            # play audio
            playsound.playsound(filename)

            # hapus file setelah selesai
            os.remove(filename)
        except Exception as e:
            print("TTS Error:", e)

    threading.Thread(target=_run, daemon=True).start()

last_gesture = None
last_speak_time = 0
speak_delay =1  # detik

# ==============================
# Fungsi Tambahan: UI Modern
# ==============================
def draw_text(img, text, pos, font=cv2.FONT_HERSHEY_SIMPLEX,
              scale=0.9, color=(255, 255, 255), thickness=2,
              bg_color=(0, 0, 0)):
    """ Teks dengan background transparan """
    x, y = pos
    (w, h), _ = cv2.getTextSize(text, font, scale, thickness)
    overlay = img.copy()
    cv2.rectangle(overlay, (x, y - h - 5), (x + w + 10, y + 5), bg_color, -1)
    alpha = 0.4  # transparansi
    img = cv2.addWeighted(overlay, alpha, img, 1 - alpha, 0)
    cv2.putText(img, text, (x + 5, y), font, scale, color, thickness)
    return img

# ==============================
# Main Program
# ==============================
cap = cv2.VideoCapture(0)

with mp_hands.Hands(
    max_num_hands=2,
    min_detection_confidence=0.7,
    min_tracking_confidence=0.7) as hands, \
    mp_face_detection.FaceDetection(
    min_detection_confidence=0.5) as face_detection:

    while True:
        success, image = cap.read()
        if not success:
            print("Kamera tidak terdeteksi.")
            break

        image = cv2.flip(image, 1)  # mirror view
        h, w, c = image.shape
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        results_hands = hands.process(image_rgb)
        results_face = face_detection.process(image_rgb)

        # ==============================
        # Panel Info
        # ==============================
        image = draw_text(image, "Hand & Face Recognition", (10, 40),
                          scale=1, color=(255, 255, 255), bg_color=(0, 128, 255))

        # ==============================
        # Deteksi Tangan
        # ==============================
        if results_hands.multi_hand_landmarks:
            num_hands = len(results_hands.multi_hand_landmarks)
            image = draw_text(image, f'Hands Detected: {num_hands}', (10, 80),
                              color=(0, 255, 0), bg_color=(0, 0, 0))

            # kalau ada 2 tangan, hitung jarak
            if num_hands == 2:
                hand1_landmarks = results_hands.multi_hand_landmarks[0]
                hand2_landmarks = results_hands.multi_hand_landmarks[1]
                x1, y1 = int(hand1_landmarks.landmark[0].x * w), int(hand1_landmarks.landmark[0].y * h)
                x2, y2 = int(hand2_landmarks.landmark[0].x * w), int(hand2_landmarks.landmark[0].y * h)
                distance = ((x2 - x1)**2 + (y2 - y1)**2)**0.5
                image = draw_text(image, f'Hand Distance: {int(distance)} px', (10, 120),
                                  color=(0, 255, 255), bg_color=(50, 50, 50))

            # loop semua tangan
            for hand_landmarks, hand_handedness in zip(results_hands.multi_hand_landmarks, results_hands.multi_handedness):
                mp_drawing.draw_landmarks(image, hand_landmarks, mp_hands.HAND_CONNECTIONS)

                hand_label = hand_handedness.classification[0].label
                fingers_open = count_fingers(hand_landmarks, hand_label)
                gesture_text = gesture_dict.get(fingers_open, "Tidak dikenali")

                cx = int(hand_landmarks.landmark[9].x * w)
                cy = int(hand_landmarks.landmark[9].y * h)

                text_x = cx - 100 if hand_label == "Left" else cx + 20
                image = draw_text(image, f'{hand_label}: {gesture_text}',
                                  (text_x, cy - 20), color=(255, 255, 255),
                                  bg_color=(128, 0, 128))

                # ==============================
                # TTS untuk Gesture
                # ==============================
                if gesture_text != "Tidak dikenali":
                    now = time.time()
                    if gesture_text != last_gesture or (now - last_speak_time) > speak_delay:
                        print("🎯 Gesture dikenali:", gesture_text)
                        speak(gesture_text)
                        last_gesture = gesture_text
                        last_speak_time = now

        # ==============================
        # Deteksi Wajah
        # ==============================
        if results_face.detections:
            for detection in results_face.detections:
                mp_drawing.draw_detection(image, detection)
                bboxC = detection.location_data.relative_bounding_box
                ih, iw, _ = image.shape
                x, y, w_box, h_box = int(bboxC.xmin * iw), int(bboxC.ymin * ih), \
                                     int(bboxC.width * iw), int(bboxC.height * ih)
                image = draw_text(image, 'Face Detected', (x, y - 10),
                                  color=(0, 255, 0), bg_color=(0, 0, 0))

        cv2.imshow('Hand & Face Detection (Google TTS)', image)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

cap.release()
cv2.destroyAllWindows()
