Nama="Seno"
Gender="Laki-laki"
Umur=20
Prodi="Teknik Informatika"
Rombel="TI-06"
Alamat="Depok"
print("\nNama",Nama,"\nGender",Gender,"\nUmur",Umur,"\nProdi",Prodi,"\nRombel",Rombel,"\nAlamat",Alamat)