import pyttsx3

engine = pyttsx3.init()
engine.say("Halo, ini percobaan text to speech menggunakan pyttsx3.")
engine.runAndWait()
